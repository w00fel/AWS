This is the plugin root directory. Install cloud provider plugins into
subdirectories under this directory. For example, for a plugin JAR foo.jar,
create a directory "foo" and install the JAR there.

On startup, Cloudera Director scans for plugins starting from this directory.
It only expects one plugin JAR per directory.
